# print(2+3*4)
#
# side_j = int(input("Please enter the length of the side of the square: \n\n"))
# print("\nThe area of your square is ", side_j **2, "\n\n")

a = int(input("Please enter the length of a:"))
b = int(input("Please enter the length of b:"))

total_area = b*a+a**2

print("THe area of the shape is: ", total_area)

