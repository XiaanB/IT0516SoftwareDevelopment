my_age = 32
name = "anna"
height = 1.76
i = 1

print(my_age)