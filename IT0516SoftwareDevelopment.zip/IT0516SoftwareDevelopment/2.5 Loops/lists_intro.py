computer_parts = ["computer",
                  "monitor",
                  "keyboard",
                  "mouse mat"
                  ]

for part in computer_parts:
    print(part)

print()
""" print the 3rd item, indexing start at 0"""
print(computer_parts[2])

"""print the first 3 items in the list"""
print(computer_parts[0:3])

"""print the last item in list"""
print(computer_parts[-1])


