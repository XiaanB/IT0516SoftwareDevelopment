#Variable set to integer

my_score = 201

print("The type of my_score is:", type(my_score), "\n ")
print("my_score is ", my_score, "\n")

print("Casting to a string... \n")
my_score = str(my_score)

print("The type of my_score is:", type(my_score), "\n ")
print("my_score is ", my_score, "\n")
