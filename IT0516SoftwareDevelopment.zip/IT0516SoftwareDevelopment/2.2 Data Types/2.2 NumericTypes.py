#Interger
x = 10
y = 2465511454663471
z = -3255522

print(x)
print(type(x))
print(type(y))
print(type(z))

#Floating-Point Values
x = 5.2
y = -105.06
z = 12e3

print(x)
print(type(x))

#complex Number
my_complex = 6 + 3j
print(my_complex)
print(my_complex.real)
print(my_complex.imag)