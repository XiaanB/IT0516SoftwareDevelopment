my_string = "Aoteroa - the land of the long Cloud"
print(my_string)

print(ord("A"))