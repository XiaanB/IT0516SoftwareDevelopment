cats = 5
dogs = 10
print(cats)
print(dogs)
print(cats+dogs)

Shopping = 'apples', 'rice', 'chips', 'toothpaste'
print(Shopping)

x = True
print(bool(x))