print("Welcome to your first data entry program \n")
user_name = input("Please enter your name...\n")
user_yob = int(input("Please enter your year of birth...\n"))

print("Thank you for your input. \n")
print("Thank you, " + user_name + " for entering you yob.")
print("You are ", 2023 - user_yob, " years old")
