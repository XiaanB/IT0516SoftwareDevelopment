# Changing the menu selection to a dic.
available_selections = {
    0: "Exit Program",
    1: "Submit helpdesk ticket",
    2: "Show all tickets",
    3: "Respond to ticket by number",
    4: "Ticket stats",
    5: "Re-open resolved ticket",
}


# Changing the menu print to a def. Printing a nice welcome sreenn for the user to make a selection


def print_menu():
    print("IT5014 Helpdesk Ticketing System:")
    print("_______________________________________________________")
    print("Select one of the following choices: \n")

    for key in available_selections.keys():
        print(key, '--', available_selections[key])
    print("_______________________________________________________")

    # User get a chance to make a selection based on the above options. Error handling.
    # while True:
    #     try:
    #         choice = input("\nPlease select and option between 0-5:\n")
    #     except ValueError:
    #         print('Wrong input. Please enter a number ...')


def exit_program():
    print('Thank you for using the IT ticketing program.')
    exit()


def submit_helpdesk_ticket():
    print('Code will follow to add a ticket to a nested list.')


def show_all_tickets():
    print('Code to follow to shoe all tickets.')


def respond_to_a_ticket():
    print('Code to close a ticket and to give a response.')


def ticket_stats():
    print('Code to show all open, closed tickets and how many tickets to be done.')


def reopen_ticket():
    print('Code to open a closed ticket')


if __name__ == '__main__':
    while True:
        print_menu()
        # User get a chance to make a selection based on the above options. Error handling.
        choice = ''
        try:
            choice = int(input('Enter your choice: '))
        except ValueError:
            print('Wrong input. Please enter a number ...')
        # Check what choice was entered and act accordingly
        if choice == 1:
            submit_helpdesk_ticket()
        elif choice == 2:
            show_all_tickets()
        elif choice == 3:
            respond_to_a_ticket()
        elif choice == 4:
            ticket_stats()
        elif choice == 5:
            reopen_ticket()
        elif choice == 0:
            exit_program()
        else:
            print('Invalid option. Please enter a number between 1 and 4.')